/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Mon 16. Jul 14:25:24 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFormLayout>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>
#include "frameclass.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    FrameClass *frameWidget;
    QFrame *line;
    QFormLayout *formLayout;
    QComboBox *horizontalBoardsComboBox;
    QComboBox *verticalBoardsComboBox;
    QComboBox *receiversPerBoardComboBox;
    QComboBox *tranceiversPerBoardComboBox;
    QComboBox *driverComboBox;
    QLabel *horizontalBoardsLabel;
    QLabel *verticalBoardsLabel;
    QLabel *receiversPerBoardLabel;
    QLabel *tranceiversPerBoardLabel;
    QLabel *driverLabel;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(455, 400);
        MainWindow->setMinimumSize(QSize(455, 400));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        centralWidget->setMinimumSize(QSize(455, 358));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        frameWidget = new FrameClass(centralWidget);
        frameWidget->setObjectName(QString::fromUtf8("frameWidget"));
        frameWidget->setMinimumSize(QSize(300, 200));
        QPalette palette;
        QBrush brush(QColor(255, 255, 255, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush);
        palette.setBrush(QPalette::Active, QPalette::Window, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush);
        frameWidget->setPalette(palette);
        frameWidget->setAutoFillBackground(true);

        verticalLayout->addWidget(frameWidget);

        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        horizontalBoardsComboBox = new QComboBox(centralWidget);
        horizontalBoardsComboBox->setObjectName(QString::fromUtf8("horizontalBoardsComboBox"));

        formLayout->setWidget(0, QFormLayout::LabelRole, horizontalBoardsComboBox);

        verticalBoardsComboBox = new QComboBox(centralWidget);
        verticalBoardsComboBox->setObjectName(QString::fromUtf8("verticalBoardsComboBox"));

        formLayout->setWidget(1, QFormLayout::LabelRole, verticalBoardsComboBox);

        receiversPerBoardComboBox = new QComboBox(centralWidget);
        receiversPerBoardComboBox->setObjectName(QString::fromUtf8("receiversPerBoardComboBox"));

        formLayout->setWidget(2, QFormLayout::LabelRole, receiversPerBoardComboBox);

        tranceiversPerBoardComboBox = new QComboBox(centralWidget);
        tranceiversPerBoardComboBox->setObjectName(QString::fromUtf8("tranceiversPerBoardComboBox"));

        formLayout->setWidget(3, QFormLayout::LabelRole, tranceiversPerBoardComboBox);

        driverComboBox = new QComboBox(centralWidget);
        driverComboBox->setObjectName(QString::fromUtf8("driverComboBox"));

        formLayout->setWidget(4, QFormLayout::LabelRole, driverComboBox);

        horizontalBoardsLabel = new QLabel(centralWidget);
        horizontalBoardsLabel->setObjectName(QString::fromUtf8("horizontalBoardsLabel"));

        formLayout->setWidget(0, QFormLayout::FieldRole, horizontalBoardsLabel);

        verticalBoardsLabel = new QLabel(centralWidget);
        verticalBoardsLabel->setObjectName(QString::fromUtf8("verticalBoardsLabel"));

        formLayout->setWidget(1, QFormLayout::FieldRole, verticalBoardsLabel);

        receiversPerBoardLabel = new QLabel(centralWidget);
        receiversPerBoardLabel->setObjectName(QString::fromUtf8("receiversPerBoardLabel"));

        formLayout->setWidget(2, QFormLayout::FieldRole, receiversPerBoardLabel);

        tranceiversPerBoardLabel = new QLabel(centralWidget);
        tranceiversPerBoardLabel->setObjectName(QString::fromUtf8("tranceiversPerBoardLabel"));

        formLayout->setWidget(3, QFormLayout::FieldRole, tranceiversPerBoardLabel);

        driverLabel = new QLabel(centralWidget);
        driverLabel->setObjectName(QString::fromUtf8("driverLabel"));

        formLayout->setWidget(4, QFormLayout::FieldRole, driverLabel);


        verticalLayout->addLayout(formLayout);

        verticalLayout->setStretch(0, 1);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 455, 20));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(horizontalBoardsComboBox, SIGNAL(activated(QString)), frameWidget, SLOT(setHorBoards(QString)));
        QObject::connect(receiversPerBoardComboBox, SIGNAL(activated(QString)), frameWidget, SLOT(setRxPerBoard(QString)));
        QObject::connect(verticalBoardsComboBox, SIGNAL(activated(QString)), frameWidget, SLOT(setVerBoards(QString)));
        QObject::connect(tranceiversPerBoardComboBox, SIGNAL(activated(QString)), frameWidget, SLOT(setTxPerBoard(QString)));

        horizontalBoardsComboBox->setCurrentIndex(2);
        verticalBoardsComboBox->setCurrentIndex(1);
        receiversPerBoardComboBox->setCurrentIndex(7);
        tranceiversPerBoardComboBox->setCurrentIndex(1);
        driverComboBox->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        horizontalBoardsComboBox->clear();
        horizontalBoardsComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "5", 0, QApplication::UnicodeUTF8)
        );
        verticalBoardsComboBox->clear();
        verticalBoardsComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "5", 0, QApplication::UnicodeUTF8)
        );
        receiversPerBoardComboBox->clear();
        receiversPerBoardComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "5", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "6", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "7", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "8", 0, QApplication::UnicodeUTF8)
        );
        tranceiversPerBoardComboBox->clear();
        tranceiversPerBoardComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "2", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "3", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "4", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "5", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "6", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "7", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "8", 0, QApplication::UnicodeUTF8)
        );
        driverComboBox->clear();
        driverComboBox->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "YES", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "NO", 0, QApplication::UnicodeUTF8)
        );
        horizontalBoardsLabel->setText(QApplication::translate("MainWindow", "Horizontal Boards", 0, QApplication::UnicodeUTF8));
        verticalBoardsLabel->setText(QApplication::translate("MainWindow", "Vertical Boards", 0, QApplication::UnicodeUTF8));
        receiversPerBoardLabel->setText(QApplication::translate("MainWindow", "Receivers per Board", 0, QApplication::UnicodeUTF8));
        tranceiversPerBoardLabel->setText(QApplication::translate("MainWindow", "Tranceivers per Board", 0, QApplication::UnicodeUTF8));
        driverLabel->setText(QApplication::translate("MainWindow", "Driver ON", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
