#include "frameclass.h"
#include "math.h"
#include <QRegion>

FrameClass::FrameClass(QWidget *parent) :
    QWidget(parent)
{
    horizontalBoards = 3;
    verticalBoards = 2;
    tranceiversPerBoard = 2;
    receiversPerBoard = 8;

    gridIsOn = false;
    gridSize = 1;

    recalculateParameters();
}

void FrameClass::paintEvent (QPaintEvent *)
{
    QPainter *qpainter = new QPainter(this);

    recalculateParameters();

    drawBorders(qpainter);

    if(gridIsOn)
        drawGrid(qpainter);

    memoryIsClean = true;

    qpainter->end();
    delete qpainter;
}
void FrameClass::saveImage()
{
    QPixmap pixmap(widthOfFrame, heightOfFrame);
    this->render(&pixmap,QPoint(), QRegion(WIDTH_OF_BORDER,WIDTH_OF_BORDER, widthOfFrame, heightOfFrame, QRegion::Rectangle));
    pixmap.save("Frame.png");
}

void FrameClass::calculateRxTxPositions()
{
    qreal topBoardTxY = rect().y() + WIDTH_OF_BORDER;
    qreal bottomBoardTxY = topBoardTxY + heightOfFrame;

    qreal topBoardRxY = rect().y() + WIDTH_OF_BORDER/2;
    qreal bottomBoardRxY = bottomBoardTxY + WIDTH_OF_BORDER/2;

    qreal leftBoardTxX = rect().x() + WIDTH_OF_BORDER;
    qreal rightBoardTxX = leftBoardTxX + widthOfFrame;

    qreal leftBoardRxX = rect().x() + WIDTH_OF_BORDER/2;
    qreal rightBoardRxX = rightBoardTxX + WIDTH_OF_BORDER/2;


    for(uchar i = 0; i < horizontalBoards; i++)
    {
        for(uchar j = 0; j < tranceiversPerBoard; j++)
        {
            qreal xCoord = rect().x() + WIDTH_OF_BORDER + i*widthOfSensorBoard + widthOfSensorBoard/2;
            qreal delta = widthOfSensorBoard/8.0;
            (0 == j%2)?
                xCoord += j/2.0*delta + delta/2.0:
                xCoord -= (j-1)/2.0*delta + delta/2.0;

            bottomSide[i].tranceivers[j].setX(xCoord);
            bottomSide[i].tranceivers[j].setY(bottomBoardTxY);
            topSide[i].tranceivers[j].setX(xCoord);
            topSide[i].tranceivers[j].setY(topBoardTxY);
        }

        for(uchar j = 0; j < receiversPerBoard; j++)
        {
            qreal xCoord = rect().x() + WIDTH_OF_BORDER + i*widthOfSensorBoard + j*widthOfReceiver + widthOfReceiver/2.0;

            bottomSide[i].receivers[j].setX(xCoord);
            bottomSide[i].receivers[j].setY(bottomBoardRxY);
            topSide[i].receivers[j].setX(xCoord);
            topSide[i].receivers[j].setY(topBoardRxY);
        }
    }

    for(uchar i = 0; i < verticalBoards; i++)
    {
        for(uchar j = 0; j < tranceiversPerBoard; j++)
        {
            qreal yCoord = rect().y() + WIDTH_OF_BORDER + i*heightOfSensorBoard + heightOfSensorBoard/2.0;
            qreal delta = heightOfSensorBoard/8.0;
            (0 == j%2)?
                yCoord += j/2.0*delta + delta/2.0:
                yCoord -= (j-1)/2.0*delta + delta/2.0;

            leftSide[i].tranceivers[j].setX(leftBoardTxX);
            leftSide[i].tranceivers[j].setY(yCoord);
            rightSide[i].tranceivers[j].setX(rightBoardTxX);
            rightSide[i].tranceivers[j].setY(yCoord);
        }

        for(uchar j = 0; j < receiversPerBoard; j++)
        {

            qreal yCoord = rect().y() + WIDTH_OF_BORDER + i*heightOfSensorBoard + j*heightOfReceiver + heightOfReceiver/2.0;

            leftSide[i].receivers[j].setX(leftBoardRxX);
            leftSide[i].receivers[j].setY(yCoord);
            rightSide[i].receivers[j].setX(rightBoardRxX);
            rightSide[i].receivers[j].setY(yCoord);
        }
    }
}

void FrameClass::drawGrid(QPainter *painter)
{
    qreal dx = widthOfReceiver/gridSize;
    qreal dy = heightOfReceiver/gridSize;
    uint xN = widthOfFrame/dx;
    uint yN = heightOfFrame/dy;

    emit setNumberOfCells(xN*yN*tranceiversPerBoard*receiversPerBoard*(verticalBoards + horizontalBoards)*4/1024);
    printf("%d",xN*yN*tranceiversPerBoard*receiversPerBoard*(verticalBoards + horizontalBoards)*4);

    for(uint i = 0; i < xN; i++)
    {
        QPointF start = QPointF(WIDTH_OF_BORDER + i*dx, WIDTH_OF_BORDER);
        QPointF end = QPointF(WIDTH_OF_BORDER + i*dx, WIDTH_OF_BORDER + heightOfFrame);
        painter->drawLine(start,end);
    }
    for(uint i = 0; i < yN; i++)
        painter->drawLine(WIDTH_OF_BORDER,WIDTH_OF_BORDER + i*dy,
                          WIDTH_OF_BORDER + widthOfFrame,WIDTH_OF_BORDER + i*dy);
}

void FrameClass::drawLinesTest(QPainter *painter,const uchar *connectionData)
{
    QPen oldPen = painter->pen();
    QPen pen = oldPen;
    uint counter = 0;

    pen.setColor(Qt::red);

    painter->setPen(pen);
    qreal dx,dy;

    //left Tx to all Rx
    for(char i = verticalBoards - 1; i >= 0; i--)
    {
        for(char j = tranceiversPerBoard - 1; j >= 0; j--)
        {
            for(char k = 0; k < horizontalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(bottomSide[k].receivers[m].x() - leftSide[i].tranceivers[j].x());
                    dy = fabs(bottomSide[k].receivers[m].y() - leftSide[i].tranceivers[j].y())*coefWtoH;
                    if(dx - dy >= 0 && dx/dy <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(leftSide[i].tranceivers[j]);
                        path.lineTo(k*widthOfSensorBoard + m*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(k*widthOfSensorBoard + (m+1)*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(leftSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(leftSide[i].tranceivers[j],bottomSide[k].receivers[m]);
                        //if(connectionData[counter] & (1 << m))
                }

                counter++;
            }

            for(char k = verticalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(rightSide[k].receivers[m].x() - leftSide[i].tranceivers[j].x());
                    dy = fabs(rightSide[k].receivers[m].y() - leftSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dx - dy >= 0 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(leftSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + (k + 1)*heightOfSensorBoard - m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + (k + 1)*heightOfSensorBoard - (m + 1)*heightOfReceiver);
                        path.lineTo(leftSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(leftSide[i].tranceivers[j],rightSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = horizontalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(topSide[k].receivers[m].x() - leftSide[i].tranceivers[j].x());
                    dy = fabs(topSide[k].receivers[m].y() - leftSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dx - dy >= 0 && dx/dy <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(leftSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + m*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + (m + 1)*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(leftSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(leftSide[i].tranceivers[j],topSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = 0; k < verticalBoards; k++)
            {
//                for(char m = 0; m < receiversPerBoard; m++)
//                {
//                    dx = fabs(leftSide[k].receivers[m].x() - leftSide[i].tranceivers[j].x());
//                    dy = fabs(leftSide[k].receivers[m].y() - leftSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
//                        painter->drawLine(leftSide[i].tranceivers[j],leftSide[k].receivers[m]);
//                }
                counter++;
            }
        }
    }

    //top Tx to all Rx
    for(char i = 0; i < horizontalBoards; i++)
    {
        for(char j = 0; j < tranceiversPerBoard; j++)
        {
            for(char k = 0; k < horizontalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(bottomSide[k].receivers[m].x() - topSide[i].tranceivers[j].x());
                    dy = fabs(bottomSide[k].receivers[m].y() - topSide[i].tranceivers[j].y())*coefWtoH;

                    if(dy - dx >= 0 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(topSide[i].tranceivers[j]);
                        path.lineTo(k*widthOfSensorBoard + m*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(k*widthOfSensorBoard + (m+1)*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(topSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(topSide[i].tranceivers[j],bottomSide[k].receivers[m]);
                }

                counter++;
            }

            for(char k = verticalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(rightSide[k].receivers[m].x() - topSide[i].tranceivers[j].x());
                    dy = fabs(rightSide[k].receivers[m].y() - topSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dy - dx >= 0 && dy/dx <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(topSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + k*heightOfSensorBoard + m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + k*heightOfSensorBoard + (m + 1)*heightOfReceiver);
                        path.lineTo(topSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(topSide[i].tranceivers[j],rightSide[k].receivers[m]);
                }

                counter++;
            }

            for(char k = horizontalBoards - 1; k >= 0; k--)
            {
//                for(char m = 0; m < receiversPerBoard; m++)
//                {
//                    dx = fabs(topSide[k].receivers[m].x() - topSide[i].tranceivers[j].x());
//                    dy = fabs(topSide[k].receivers[m].y() - topSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
//                        painter->drawLine(topSide[i].tranceivers[j],topSide[k].receivers[m]);
//                }
                counter++;
            }

            for(char k = 0; k < verticalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(leftSide[k].receivers[m].x() - topSide[i].tranceivers[j].x());
                    dy = fabs(leftSide[k].receivers[m].y() - topSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dy - dx >= 0 && dy/dx <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(topSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + (m + 1)*heightOfReceiver);
                        path.lineTo(topSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(topSide[i].tranceivers[j],leftSide[k].receivers[m]);
                }
                counter++;
            }
        }
    }

    //right Tx to all Rx
    for(char i = 0; i < verticalBoards; i++)
    {
        for(char j = 0; j < tranceiversPerBoard; j++)
        {
            for(char k = 0; k < horizontalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(bottomSide[k].receivers[m].x() - rightSide[i].tranceivers[j].x());
                    dy = fabs(bottomSide[k].receivers[m].y() - rightSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dx - dy >= 0 && dx/dy <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(rightSide[i].tranceivers[j]);
                        path.lineTo(k*widthOfSensorBoard + m*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(k*widthOfSensorBoard + (m+1)*widthOfReceiver + WIDTH_OF_BORDER,WIDTH_OF_BORDER + heightOfFrame);
                        path.lineTo(rightSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(rightSide[i].tranceivers[j],bottomSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = verticalBoards - 1; k >= 0; k--)
            {
//                for(char m = 0; m < receiversPerBoard; m++)
//                {
//                    dx = fabs(rightSide[k].receivers[m].x() - rightSide[i].tranceivers[j].x());
//                    dy = fabs(rightSide[k].receivers[m].y() - rightSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
//                        painter->drawLine(rightSide[i].tranceivers[j],rightSide[k].receivers[m]);
//                }
                counter++;
            }

            for(char k = horizontalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(topSide[k].receivers[m].x() - rightSide[i].tranceivers[j].x());
                    dy = fabs(topSide[k].receivers[m].y() - rightSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dx - dy >= 0 && dx/dy <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(rightSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + m*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + (m + 1)*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(rightSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(rightSide[i].tranceivers[j],topSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = 0; k < verticalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(leftSide[k].receivers[m].x() - rightSide[i].tranceivers[j].x());
                    dy = fabs(leftSide[k].receivers[m].y() - rightSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dx - dy >= 0&& (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(rightSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + (m + 1)*heightOfReceiver);
                        path.lineTo(rightSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(rightSide[i].tranceivers[j],leftSide[k].receivers[m]);
                }
                counter++;
            }
        }
    }

    //bottom Tx to all Rx
    for(char i = horizontalBoards - 1; i >= 0; i--)
    {
        for(char j = tranceiversPerBoard - 1; j >=  0; j--)
        {
            for(char k = 0; k < horizontalBoards; k++)
            {
//                for(char m = 0; m < receiversPerBoard; m++)
//                {
//                    dx = fabs(bottomSide[k].receivers[m].x() - bottomSide[i].tranceivers[j].x());
//                    dy = fabs(bottomSide[k].receivers[m].y() - bottomSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
//                        painter->drawLine(bottomSide[i].tranceivers[j],bottomSide[k].receivers[m]);
//                }
                counter++;
            }

            for(char k = verticalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(rightSide[k].receivers[m].x() - bottomSide[i].tranceivers[j].x());
                    dy = fabs(rightSide[k].receivers[m].y() - bottomSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dy - dx >= 0 && dy/dx <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(bottomSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + k*heightOfSensorBoard + m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER + widthOfFrame, WIDTH_OF_BORDER + k*heightOfSensorBoard + (m + 1)*heightOfReceiver);
                        path.lineTo(bottomSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(bottomSide[i].tranceivers[j],rightSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = horizontalBoards - 1; k >= 0; k--)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(topSide[k].receivers[m].x() - bottomSide[i].tranceivers[j].x());
                    dy = fabs(topSide[k].receivers[m].y() - bottomSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dy - dx >= 0 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(bottomSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + m*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(WIDTH_OF_BORDER + k*widthOfSensorBoard + (m + 1)*widthOfReceiver ,WIDTH_OF_BORDER);
                        path.lineTo(bottomSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(bottomSide[i].tranceivers[j],topSide[k].receivers[m]);
                }
                counter++;
            }

            for(char k = 0; k < verticalBoards; k++)
            {
                for(char m = 0; m < receiversPerBoard; m++)
                {
                    dx = fabs(leftSide[k].receivers[m].x() - bottomSide[i].tranceivers[j].x());
                    dy = fabs(leftSide[k].receivers[m].y() - bottomSide[i].tranceivers[j].y())*coefWtoH;
//                    if(connectionData[counter] & (1 << m))
                    if(dy - dx >= 0 && dy/dx <= 1.7 && (connectionData[counter] & (1 << m) ))
                    {
                        QPainterPath path(bottomSide[i].tranceivers[j]);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + m*heightOfReceiver);
                        path.lineTo(WIDTH_OF_BORDER, WIDTH_OF_BORDER + k*heightOfSensorBoard + (m + 1)*heightOfReceiver);
                        path.lineTo(bottomSide[i].tranceivers[j]);
                        painter->drawPath(path);
                        painter->fillPath(path,QColor(Qt::black));
                    }
//                        painter->drawLine(bottomSide[i].tranceivers[j],leftSide[k].receivers[m]);
                }
                counter++;
            }
        }
    }

    painter->setPen(oldPen);
}

void FrameClass::drawBorders(QPainter *qpainter)
{
    QPen pen(qpainter->pen());

    qpainter->drawRect (rect().x(),
                        rect().y(),
                        rect().x() + rect().width() - 1,
                        rect().y() + rect().height() - 1);

    pen.setWidth(3);
    qpainter->setPen(pen);

    qpainter->drawLine(rect().x() + WIDTH_OF_BORDER,
                       rect().y(),
                       rect().x() + WIDTH_OF_BORDER,
                       rect().y() + rect().height());

    qpainter->drawLine(rect().x() + WIDTH_OF_BORDER + widthOfFrame,
                       rect().y(),
                       rect().x() + WIDTH_OF_BORDER + widthOfFrame,
                       rect().y() + rect().height());

    qpainter->drawLine(rect().x(),
                       rect().y() + WIDTH_OF_BORDER,
                       rect().x() + rect().width(),
                       rect().y() + WIDTH_OF_BORDER);

    qpainter->drawLine(rect().x(),
                       rect().y() + WIDTH_OF_BORDER + heightOfFrame,
                       rect().x() + rect().width(),
                       rect().y() + WIDTH_OF_BORDER + heightOfFrame);

    pen.setWidth(0);
    qpainter->setPen(pen);

    for( uint j = 0; j < horizontalBoards; j++ )
        for (uint i = 0; i < receiversPerBoard; i++)
        {
            pen.setWidth(0);
            qpainter->setPen(pen);
            qpainter->drawEllipse(rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard + widthOfReceiver/2 - RX_TX_RADIUS,
                                  rect().y() + WIDTH_OF_BORDER/2 - RX_TX_RADIUS,
                                  RX_TX_RADIUS*2,
                                  RX_TX_RADIUS*2);
            qpainter->drawEllipse(rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard + widthOfReceiver/2 - RX_TX_RADIUS,
                                  rect().y() + WIDTH_OF_BORDER/2 + heightOfFrame + WIDTH_OF_BORDER - RX_TX_RADIUS,
                                  RX_TX_RADIUS*2,
                                  RX_TX_RADIUS*2);

            if(i == 0)
            {
                pen.setWidth(3);
                qpainter->setPen(pen);
            }
            else
            {
                pen.setWidth(0);
                qpainter->setPen(pen);
            }

            qpainter->drawLine(rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard,
                               rect().y(),
                               rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard,
                               rect().y() + WIDTH_OF_BORDER);

            qpainter->drawLine(rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard,
                               rect().y() + heightOfFrame + WIDTH_OF_BORDER,
                               rect().x() + WIDTH_OF_BORDER + i*widthOfReceiver + j*widthOfSensorBoard,
                               rect().y() + heightOfFrame + 2*WIDTH_OF_BORDER);
        }

    for( uint j = 0; j < verticalBoards; j++ )
        for (uint i = 0; i < receiversPerBoard; i++)
        {
            pen.setWidth(0);
            qpainter->setPen(pen);
            qpainter->drawEllipse(rect().x() + WIDTH_OF_BORDER/2 - RX_TX_RADIUS,
                                  rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard + heightOfReceiver/2 - RX_TX_RADIUS,
                                  RX_TX_RADIUS*2,
                                  RX_TX_RADIUS*2);
            qpainter->drawEllipse(rect().x() + WIDTH_OF_BORDER/2 + widthOfFrame + WIDTH_OF_BORDER - RX_TX_RADIUS,
                                  rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard + heightOfReceiver/2 - RX_TX_RADIUS,
                                  RX_TX_RADIUS*2,
                                  RX_TX_RADIUS*2);
            if(i == 0)
            {
                pen.setWidth(3);
                qpainter->setPen(pen);
            }
            else
            {
                pen.setWidth(0);
                qpainter->setPen(pen);
            }

            qpainter->drawLine(rect().x(),
                               rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard,
                               rect().x() + WIDTH_OF_BORDER,
                               rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard);

            qpainter->drawLine(rect().x() + widthOfFrame + WIDTH_OF_BORDER,
                               rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard,
                               rect().x() + widthOfFrame + 2*WIDTH_OF_BORDER,
                               rect().y() + WIDTH_OF_BORDER + i*heightOfReceiver + j*heightOfSensorBoard);
        }

    FrameClass::drawLinesTest(qpainter, TEST_DATA);
}

void FrameClass::recalculateParameters()
{
    heightOfFrame = rect().y() + rect().height() - 1 - 2*WIDTH_OF_BORDER;
    widthOfFrame = rect().x() + rect().width() - 1 - 2*WIDTH_OF_BORDER;

    heightOfSensorBoard = heightOfFrame/verticalBoards;
    widthOfSensorBoard = widthOfFrame/horizontalBoards;

    coefWtoH =widthOfSensorBoard/ heightOfSensorBoard;

    widthOfReceiver = widthOfSensorBoard/receiversPerBoard;
    heightOfReceiver = heightOfSensorBoard/receiversPerBoard;

    new_x0 = rect().x();
    new_x0 = rect().y() + rect().height() - 1 - 2*WIDTH_OF_BORDER;

    FrameClass::calculateRxTxPositions();
}

void FrameClass::setHorBoards(QString text)
{
    uint tmp = text.toInt();
    if(horizontalBoards != tmp)
    {
       horizontalBoards = tmp;
       FrameClass::parametersChanged();
    }
}

void FrameClass::setVerBoards(QString text)
{
    uint tmp = text.toInt();
    if(verticalBoards != tmp)
    {
       verticalBoards = tmp;
       FrameClass::parametersChanged();
    }
}

void FrameClass::setRxPerBoard(QString text)
{
    uint tmp = text.toInt();
    if(receiversPerBoard != tmp)
    {
       receiversPerBoard = tmp;
       FrameClass::parametersChanged();
    }
}

void FrameClass::setTxPerBoard(QString text)
{
    uint tmp = text.toInt();
    if(tranceiversPerBoard != tmp)
    {
       tranceiversPerBoard = tmp;
       FrameClass::parametersChanged();
    }
}

void FrameClass::switchGridOn(bool flag)
{
    if(flag)
    {
        gridIsOn = true;
        FrameClass::parametersChanged();
    }
}

void FrameClass::switchGridOff(bool flag)
{
    if(flag)
    {
        gridIsOn = false;
        FrameClass::parametersChanged();
    }
}

void FrameClass::setGridSize(QString text)
{
    uint tmp = text.toInt();
    if(gridSize != tmp)
    {
       gridSize = tmp;
       if(gridIsOn)
           FrameClass::parametersChanged();
    }
}

void FrameClass::parametersChanged()
{
    this->recalculateParameters();
    this->update();
}
