void IOToggle(void);

int main(void)
{

    //automatically added by CoIDE
	IOToggle();

	while(1)
    {
    }
}

